package com.wirpo.hrms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jun14SecurityJpaDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

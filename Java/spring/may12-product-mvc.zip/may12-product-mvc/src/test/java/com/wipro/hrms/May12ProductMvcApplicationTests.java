package com.wipro.hrms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class May12ProductMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}

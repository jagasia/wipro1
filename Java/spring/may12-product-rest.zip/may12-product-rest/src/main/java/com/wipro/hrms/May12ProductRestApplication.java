package com.wipro.hrms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class May12ProductRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(May12ProductRestApplication.class, args);
		System.out.println("Hello world");
	}

}

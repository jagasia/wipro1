package com.wipro.hrms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class May11Jwt1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

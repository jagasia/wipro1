package com.wipro.hrms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class May11Jwt1Application {

	public static void main(String[] args) {
		SpringApplication.run(May11Jwt1Application.class, args);
	}

}

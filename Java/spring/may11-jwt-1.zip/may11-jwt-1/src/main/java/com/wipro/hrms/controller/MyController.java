package com.wipro.hrms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.hrms.enity.AuthRequest;
import com.wipro.hrms.enity.MyUser;
import com.wipro.hrms.service.UserService;
import com.wipro.hrms.util.JwtUtil;

@RestController
public class MyController {
	@Autowired
	private UserService us;
	

    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private AuthenticationManager authenticationManager;
	
	@PostMapping("/login")
	public String login(@RequestBody AuthRequest authRequest) throws Exception
	{
		System.out.println(authRequest.getUsername()+"  :  "+authRequest.getPassword());
		  try {
	            authenticationManager.authenticate(
	                    new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
	            );
	        } catch (Exception ex) {
	            throw new Exception("inavalid username/password");
	        }
	        return jwtUtil.generateToken(authRequest.getUsername());
	}
	
	@PostMapping("/signup")
	public MyUser signup(@RequestBody MyUser user)
	{
		System.out.println("new user create request "+user);
		return us.create(user);
	}
	
	@PutMapping("/update")
	public MyUser updateUser(@RequestBody MyUser user)
	{
		System.out.println("Update request came for "+user);
		return us.update(user);
	}
}
